const FX=require('./battle-effects');
// Presentation-only replacement layer. Game state, hit boxes and timers stay in the controller.
const meta=require('./ui-v2-meta');
const TYPES={'帥':'general','帅':'general','將':'general','将':'general','仕':'advisor','士':'advisor','相':'elephant','象':'elephant','車':'rook','车':'rook','俥':'rook','馬':'horse','马':'horse','傌':'horse','炮':'cannon','砲':'cannon','兵':'pawn','卒':'pawn'};
const BUTTONS={'简易 · 菜就多练局':'002','普通 · 不服就干场':'003','困难 · 棋王修罗场':'004','暂停':'005','悔棋':'006','翻转':'007','重开':'008','更多':'009','表情':'010','查看隐私保护指引':'011','取消等待':'014','收起表情':'015','查看棋局':'017','返回首页':'018'};
function install(Renderer){const p=Renderer.prototype;
 const old={header:p.header,disc:p.disc,button:p.button,uiButton:p.uiButton,uiIcon:p.uiIcon,home:p.home,text:p.text,player:p.player,profileScene:p.profileScene,preload:p.preloadGameAssets};
 p.v2Art=function(key,x,y,w,h){const m=meta[key],im=this.uiImage(key);if(!im||!m)return false;this.ctx.drawImage(im,...m.box,x,y,w,h);return true;};
 // Reuse a text-free strip of the provided player panel as a stretchable fill.
 // Draw the frame independently so baked nicknames and timer digits never leak through.
 p.v2Frame=function(key,x,y,w,h){const im=this.uiImage(key),m=meta[key];if(!im||!m)return false;const [sx,sy,sw,sh]=m.box,c=this.ctx;
 c.save();c.shadowColor='#32241455';c.shadowBlur=3;c.shadowOffsetY=2;this.rounded(x,y,w,h,14);c.fillStyle=key.endsWith('red')?'#ce342f':'#302c27';c.fill();c.shadowBlur=0;c.shadowOffsetY=0;
 this.rounded(x+2,y+2,w-4,h-4,12);c.save();c.clip();c.drawImage(im,sx+sw*.54,sy+10,2,sh-20,x+2,y+2,w-4,h-4);c.restore();c.strokeStyle='#efc77f';c.lineWidth=1;c.stroke();c.restore();return true;};
 p.text=function(label,x,y,size,color,align,bold){if(this._v2HomeFunctions){const functions=['暗棋','经典象棋','揭棋','邀请微信好友','与好友来一局','大厅匹配','在线匹配对手'];if(functions.includes(String(label)))color='#ffffff';}
 if(this._v2HomeFunctions&&color==='#ffffff'){this.ctx.save();this.ctx.shadowColor='#422600';this.ctx.shadowBlur=2;this.ctx.shadowOffsetY=1;old.text.call(this,label,x,y,size,color,align,bold);this.ctx.restore();return;}return old.text.call(this,label,x,y,size,color,align,bold);};
 p.home=function(){this._v2HomeFunctions=true;try{return old.home.call(this);}finally{this._v2HomeFunctions=false;}};
 p.referenceModeButton=function(variant,x,y,w,h,action){const im=this.uiImage('mode_reference');if(!im)return false;const selected=(this.runtime.variant||'dark')===variant,c=this.ctx;
 this._modeSprites=this._modeSprites||{};const key=variant+'|'+selected;let layer=this._modeSprites[key];if(!layer){layer=wx.createCanvas();layer.width=432;layer.height=132;const q=layer.getContext('2d'),sx=selected?94:553;
 q.beginPath();q.moveTo(66,0);q.lineTo(366,0);q.bezierCurveTo(454,0,454,132,366,132);q.lineTo(66,132);q.bezierCurveTo(-22,132,-22,0,66,0);q.closePath();q.clip();
 q.drawImage(im,sx,214,432,132,0,0,432,132);q.drawImage(im,selected?220:630,240,2,65,80,26,272,65);
 this._modeSprites[key]=layer;}
 c.drawImage(layer,x,y,w,h);old.text.call(this,{dark:'暗棋',classic:'经典',jieqi:'揭棋',fusion:'合棋'}[variant],x+w/2,y+h*.46,16,'#421d09','center',true);this.targets.push({x,y,w,h,action});return true;};
 // Sample original artwork directly. No regenerated icons or font substitution.
 p.referenceHomeFunctions=function(y,width){const im=this.uiImage('home_reference');if(!im)return false;const c=this.ctx,k=width/940,x=(375-width)/2;
 if(!this._homeLabelBackground){const layer=wx.createCanvas();layer.width=940;layer.height=551;const q=layer.getContext('2d');q.filter='saturate(.88) brightness(1.03)';q.drawImage(im,0,0);[[357,50,323,112,675],[619,264,163,84,788]].forEach(([bx,by,bw,bh,strip])=>q.drawImage(im,strip,by,1,bh,bx,by,bw,bh));q.filter='none';this._homeLabelBackground=layer;}
 const sprite=(sx,sy,sw,sh,r,action)=>{c.save();this.rounded(x+sx*k,y+sy*k,sw*k,sh*k,r*k);c.clip();c.drawImage(this._homeLabelBackground,sx,sy,sw,sh,x+sx*k,y+sy*k,sw*k,sh*k);c.restore();this.targets.push({x:x+sx*k,y:y+sy*k,w:sw*k,h:sh*k,action});};
 sprite(122,17,694,185,90,()=>this.runtime.open('difficulty'));
 sprite(51,227,414,156,60,()=>this.runtime.startGame({mode:'online'}));
 sprite(479,227,412,156,60,()=>this.runtime.startGame({mode:'online',match:'1'}));
 const label=(text,px,py,size,color,bold)=>old.text.call(this,text,x+px*k,y+py*k,size*k,color,'left',bold);
 label('人机对战',369,88,60,'#421d09',true);label('挑战智能对手，提升棋力',369,145,25,'#421d09',false);
 label('大厅匹配',622,290,38,'#ffffff',true);label('在线匹配对手',622,333,25,'#ffffff',false);
 [[195,'profile'],[408,'rules'],[624,'settings']].forEach(([sx,scene],i)=>{
 const ek=k*1.22,cx=x+(sx+60.5)*k,ey=y+405*k+18,ew=121*ek,eh=104*ek;
 c.save();this.rounded(cx-ew/2,ey,ew,eh,52*ek);c.clip();c.drawImage(im,sx,405,121,104,cx-ew/2,ey,ew,eh);c.restore();
 this.targets.push({x:cx-ew/2,y:ey,w:ew,h:140*ek,action:()=>this.runtime.open(scene)});
 old.text.call(this,i===0&&this.runtime.profile?'已登录':['登录','游戏规则','设置'][i],cx,ey+127*ek,26*ek,'#202020','center',true);
 });return true;};
 p.uiButton=function(label,x,y,w,h,action,color='cream',font=16){if(['gold','blue','green'].includes(color)){
 const compact=this.height-this.bottom-this.top<590;const tablet=this.windowWidth>=600;
 const start=compact?13:tablet?16:4;const offset={gold:0,blue:1,green:2}[color];
 if(this.v2Art('v2_home_button_'+(start+offset),x-3,y-3,w+6,h+8)){if(label)this.text(label,x+w/2,y+h/2,font,'#fff','center',true);this.targets.push({x,y,w,h,action});return;}}
 return old.uiButton.call(this,label,x,y,w,h,action,color,font);};
 p.v2TintedArt=function(key,x,y,w,h,color){const im=this.uiImage(key),m=meta[key];if(!im||!m)return false;this._v2TintCache=this._v2TintCache||new Map();const cacheKey=key+'|'+color;let layer=this._v2TintCache.get(cacheKey);if(!layer){const [sx,sy,sw,sh]=m.box;layer=wx.createCanvas();layer.width=sw;layer.height=sh;const c=layer.getContext('2d');c.drawImage(im,sx,sy,sw,sh,0,0,sw,sh);c.globalCompositeOperation='source-in';c.fillStyle=color;c.fillRect(0,0,sw,sh);c.globalCompositeOperation='source-over';this._v2TintCache.set(cacheKey,layer);}this.ctx.drawImage(layer,x,y,w,h);return true;};
 p.uiIcon=function(kind,x,y,size,color){const key='v2_icon_'+kind;if(color&&color!=='#fff'&&color!=='#ffffff'){if(this.v2TintedArt(key,x-size/2,y-size/2,size,size,color))return;}else if(this.v2Art(key,x-size/2,y-size/2,size,size))return;return old.uiIcon.call(this,kind,x,y,size,color);};
 p.button=function(label,x,y,w,h,action,primary){const id=BUTTONS[label];if(id&&this.v2Art('v2_button_'+id,x-3,y-3,w+6,h+6)){this.targets.push({x,y,w,h,action});return;}
 return old.button.call(this,label,x,y,w,h,action,primary);};
 // Piece faces come exclusively from replaceable PNG artwork, including fusion badges.
 p.pieceRing=function(x,y,r,color){const c=this.ctx;c.save();c.beginPath();c.arc(x,y,r*36/33,0,Math.PI*2);c.strokeStyle=color;c.lineWidth=r*4/33;c.stroke();c.restore();};
 p.disc=function(x,y,r,label,side='red',hidden=false,selected=false,info){
 const fusionType=!hidden&&info&&info.fusionType;
 const kind=TYPES[label]||(info&&info.kind);
 const draw=(key,cx,cy,radius)=>{const im=this.uiImage(key),m=meta[key];if(!im||!m)return false;const [sx,sy,sw,sh]=m.box,k=radius*2/Math.max(sw,sh);this.ctx.drawImage(im,sx,sy,sw,sh,cx-sw*k/2,cy-sh*k/2,sw*k,sh*k);return true;};
 const c=this.ctx;c.save();c.imageSmoothingEnabled=true;c.imageSmoothingQuality='high';
 // Never fall back to font-drawn faces while images are loading.
 draw(hidden?'v2_piece_hidden':fusionType?'v2_fusion_'+side+'_'+fusionType:'v2_piece_'+side+'_'+kind,x,y,r);
 c.restore();if(selected)this.pieceRing(x,y,r,'#fff');
 };
 p.fusionHints=function(controller,b){const d=controller.data,s=controller._state,F=require('../utils/fusion');if(!d.selectedId||d.paused)return;const ctx=this.ctx;ctx.save();ctx.translate(b.x,b.y);ctx.scale(b.w/720,b.h/800);if(!this._fusionHints||this._fusionHints.state!==s||this._fusionHints.id!==d.selectedId){const points=[];for(let y=0;y<10;y++)for(let x=0;x<9;x++){const a=F.attempt(s,d.selectedId,{x,y});if(a)points.push({x,y,a});}this._fusionHints={state:s,id:d.selectedId,points};}for(const {x,y,a} of this._fusionHints.points){const t=this.boardPoint({x,y},d.flipped);ctx.strokeStyle=a.fusion?'#ffd24d':a.removed.length?'#ef8880':'#ffffff';if(!a.fusion&&a.removed.length)this.pieceRing(t.x,t.y,33,'#ef8880');else{ctx.lineWidth=a.fusion?3:2;ctx.beginPath();ctx.arc(t.x,t.y,a.fusion?35:12,0,Math.PI*2);ctx.stroke();}if(a.fusion){ctx.beginPath();ctx.arc(t.x,t.y,40,0,Math.PI*2);ctx.stroke();if(a.moving.general)this.text('王',t.x,t.y-44,15,'#ffd24d','center');}}ctx.restore();};
 p.captureHints=function(controller,b){
 const d=controller.data,s=controller._state;if(!d.selectedId||d.paused||d.ended)return;
 if(s.variant==='fusion'){this.fusionHints(controller,b);return;}
 if(!this._captureHints||this._captureHints.state!==s||this._captureHints.id!==d.selectedId){
  const points=[],G=require('../utils/game-engine');for(const p of s.pieces)if(p.id!==d.selectedId&&G.legalAttempt(s.pieces,d.selectedId,p,s.turn))points.push({x:p.x,y:p.y});
  this._captureHints={state:s,id:d.selectedId,points};
 }
 const c=this.ctx;c.save();c.translate(b.x,b.y);c.scale(b.w/720,b.h/800);for(const p of this._captureHints.points){const q=this.boardPoint(p,d.flipped);this.pieceRing(q.x,q.y,33,'#ef8880');}c.restore();
 };
 p.captureTray=function(captured,y,width=335){const r=33*this.boardRect.w/720*.8,step=2*r+3,columns=Math.max(1,Math.floor(width/step));
 captured.forEach((piece,i)=>this.disc(22+r+(i%columns)*step,y+r+Math.floor(i/columns)*step,r,piece.text,piece.side));
 return Math.max(step,Math.ceil(captured.length/columns)*step);
 };
 p.player=function(side,name,avatar,y,captured,data,now,capturePlacement='below'){const active=data.turn===side&&!data.ended&&!data.waiting;
 if(!this.v2Frame('v2_player_bar_'+side,16,y,343,48))return old.player.call(this,side,name,avatar,y,captured,data,now);
 const c=this.ctx;c.save();c.beginPath();c.arc(41,y+24,17,0,Math.PI*2);c.clip();const loaded=this.image(avatar,24,y+7,34,34);c.restore();
 if(!loaded&&!this.v2Art('v2_avatar_fallback_'+side,22,y+5,38,38))this.disc(41,y+23,16,side==='red'?'帥':'將',side);
 if(active){c.save();c.beginPath();c.arc(41,y+24,21,0,Math.PI*2);c.strokeStyle=side==='red'?'#b71e16':'#302720';c.lineWidth=1.5;c.stroke();c.restore();}
 const chars=Array.from((name||'').replace(/\s*·\s*/g,'·')),limit=active?5:13,short=chars.slice(0,limit).join('')+(chars.length>limit?'…':'');this.text(short,68,y+17,12,side==='red'?'#ac231a':'#191919');this.text(active?(data.paused?'计时暂停':'当前行棋'):'等待对方',68,y+34,11,'#9c8567');
 if(active){const g=c.createLinearGradient(268,y+5,268,y+44);g.addColorStop(0,'#fff080');g.addColorStop(1,'#ffc837');this.card(145,y+7,85,34,g,'#edb12c');const clock=this.uiImage('v2_player_bar_black');if(clock)c.drawImage(clock,536,101,48,45,149,y+13,20,20);this.text(data.seconds+'秒',223,y+25,19,data.seconds<=10?'#c33d2b':'#ae1c10','right',true);}
 if(capturePlacement==='below')this.captureTray(captured,y+58);
 };
 p.profileScene=function(){old.profileScene.call(this);if(!this.runtime.loginBusy&&!this.runtime._privacyBusy){const b=this.profileButtonRect();this.v2Art('v2_profile_authorize_button',b.x,b.y,b.w,b.h);}};
 // The generated reference contains a matte outside the plaque. Canvas clips the
 // illustrated outline before drawing; no matte/checker pixels enter the scene.
 p.matchTitleFrame=function(x,y,w,h){const im=this.uiImage('match_title_frame');if(!im)return false;const c=this.ctx;c.save();c.translate(x,y);c.scale(w/2057,h/764);c.beginPath();
 c.moveTo(268,169);c.lineTo(1777,169);c.bezierCurveTo(1841,169,1881,194,1905,257);c.bezierCurveTo(1970,274,1994,302,2008,361);c.lineTo(2020,389);c.lineTo(2008,424);c.bezierCurveTo(1995,473,1970,500,1908,520);c.bezierCurveTo(1884,574,1847,599,1793,600);c.lineTo(248,600);c.bezierCurveTo(194,600,161,578,145,528);c.bezierCurveTo(85,514,58,479,47,432);c.lineTo(41,390);c.lineTo(54,352);c.bezierCurveTo(65,306,88,279,145,261);c.bezierCurveTo(166,205,201,173,268,169);c.closePath();
 // Leaves are separate contours, safely inside the illustrated edges.
 c.moveTo(211,89);c.bezierCurveTo(184,110,175,142,185,177);c.lineTo(239,167);c.bezierCurveTo(254,141,245,111,211,89);c.closePath();
 c.moveTo(336,122);c.bezierCurveTo(294,120,260,137,247,165);c.lineTo(290,167);c.bezierCurveTo(313,159,326,143,336,122);c.closePath();
 c.moveTo(79,193);c.bezierCurveTo(94,230,109,254,141,261);c.lineTo(174,214);c.bezierCurveTo(145,180,110,182,79,193);c.closePath();
 c.clip();c.drawImage(im,0,0,2057,764);c.restore();return true;};
 p.header=function(title,back=true){if(this.runtime.scene!=='game'||back)return old.header.call(this,title,back);
 const w=220,h=58,x=(375-w)/2,y=this.top-31;
 if(!this.matchTitleFrame(x,y,w,h)){const g=this.ctx.createLinearGradient(0,y,0,y+h);g.addColorStop(0,'#854221');g.addColorStop(1,'#512913');this.card(x+4,this.top-13,w-8,32,g,'#e9ac51');}
 this.ctx.save();this.ctx.shadowColor='#331706';this.ctx.shadowBlur=1;this.ctx.shadowOffsetY=1;this.text(title,187.5,y+h/2,15,'#fff9eb','center',true);this.ctx.restore();
 };
 p.game=function(now){const c=this.runtime.controller;if(!c)return;const d=c.data,motion=FX.frame(c,now),visualNow=c._battle&&c._battle.pausedAt!==null?c._battle.pausedAt:now;this.layoutBoard(d);const b=this.boardRect;
 const view=this._boardView||(this._boardView={});view.pieces=motion&&motion.pieces||d.pieces;view.flipped=d.flipped;view.selectedId=d.selectedId;view.lastMoveId=motion?(visualNow-motion.at>=motion.timings.contact?motion.lastMoveId:motion.beforeLastMoveId):d.lastMoveId;
 const afterContact=!motion||visualNow-motion.at>=motion.timings.contact;
 const topCaptured=motion?(afterContact?motion.afterBySide:motion.beforeBySide)[d.topSide]||[]:d.topCaptured;
 const bottomCaptured=motion?(afterContact?motion.afterBySide:motion.beforeBySide)[d.bottomSide]||[]:d.bottomCaptured;
 const warning=FX.warningPhase(c,now);
 this.header(({dark:'暗棋',classic:'经典象棋',jieqi:'揭棋',fusion:'合棋'})[c._state&&c._state.variant||this.runtime.variant||'dark']+' · 对局中',false);
 if(d.mode==='ai'&&!d.ended)this.button('暂停',16,this.top-16,56,36,()=>c.togglePause());
 this.player(d.topSide,d.topName,d.topAvatar,this.top+28,topCaptured,d,now);if(d.turn===d.topSide&&!d.paused)FX.danger(this,this.top+28,warning);
 this.board(view,b,motion,visualNow);
 if(!motion)this.captureHints(c,b);
 this.ctx.save();this.ctx.translate(b.x,b.y);this.ctx.scale(b.w/720,b.h/800);
 if(c._battle)FX.drawCues(this,c._battle.cues,visualNow,d.flipped);
 FX.rings(this,view,motion,visualNow,c._battle&&c._battle.selection);this.ctx.restore();const boardBottom=b.y+b.h*(1094/1200);
 const trayY=boardBottom+7,step=this.captureTray(bottomCaptured,trayY);
 // Reserve two captured-piece rows from the start so the player bar stays still.
 const rowStep=2*33*b.w/720*.8+3,trayHeight=Math.max(64,2*rowStep+6,step);
 if(d.pendingChase&&(d.mode!=='ai'||d.turn==='red'))this.button('结束行动',264,trayY+36,95,28,()=>c.finishChase(),true);
 const playerY=trayY+trayHeight+5;this.player(d.bottomSide,d.bottomName,d.bottomAvatar,playerY,[],d,now,'none');if(d.turn===d.bottomSide&&!d.paused)FX.danger(this,playerY,warning);
 if(!d.waiting&&!d.ended)this.button('表情',264,playerY+7,88,34,()=>c.toggleStickers());
 const by=playerY+58;[['悔棋','undo'],['翻转','flip'],['重开','restart'],['更多','more']].forEach(([label,fn],i)=>this.button(label,16+i*88,by,79,46,()=>c[fn]()));
 if(d.stickerImage)this.image(d.stickerImage,102,b.y+b.h*.25,171,171);
 if(d.waiting){this.overlay();this.card(27,this.top+145,321,227);this.text('等待真人对手',187.5,this.top+178,22,'#74512d','center',true);this.text('匹配倒计时 '+Math.max(0,d.matchSeconds||0)+' 秒',187.5,this.top+202,14,'#a47745','center');this.button('邀请微信好友',54,this.top+221,267,46,()=>this.runtime.share(),true);this.button('取消等待',54,this.top+279,267,46,()=>c.cancelWait());}
 if(d.showStickers)this.stickerSheet(c);
 if(d.showResult)this.result(c);if(d.manualPaused){this.overlay();const y=Math.max(this.top+60,(this.height-180)/2);this.card(35,y,305,180);this.text('对局已暂停',187.5,y+39,22,'#74512d','center',true);this.text('计时与 AI 均已暂停',187.5,y+76,13,'#927650','center');this.button('继续对局',64,y+110,247,46,()=>c.togglePause(),true);}
 };
 // Reference battle controls; cached source artwork, with live labels and timers.
 p.battleArt=function(box,x,y,w,h,r,blank,source='game_reference'){const im=this.uiImage(source);if(!im)return false;
 this._battleArt=this._battleArt||{};const key=source+'|'+box.join(',')+'|'+r+'|'+JSON.stringify(blank);let layer=this._battleArt[key];
 if(!layer){layer=wx.createCanvas();layer.width=box[2];layer.height=box[3];const q=layer.getContext('2d'),[sx,sy,sw,sh]=box;
 q.beginPath();q.moveTo(r,0);q.lineTo(sw-r,0);q.quadraticCurveTo(sw,0,sw,r);q.lineTo(sw,sh-r);q.quadraticCurveTo(sw,sh,sw-r,sh);q.lineTo(r,sh);q.quadraticCurveTo(0,sh,0,sh-r);q.lineTo(0,r);q.quadraticCurveTo(0,0,r,0);q.closePath();q.clip();q.drawImage(im,...box,0,0,sw,sh);
 if(blank){q.save();if(sw===774){q.beginPath();q.moveTo(43,5);q.lineTo(sw-43,5);q.quadraticCurveTo(sw-5,5,sw-5,43);q.lineTo(sw-5,sh-43);q.quadraticCurveTo(sw-5,sh-5,sw-43,sh-5);q.lineTo(43,sh-5);q.quadraticCurveTo(5,sh-5,5,sh-43);q.lineTo(5,43);q.quadraticCurveTo(5,5,43,5);q.closePath();q.clip();}q.drawImage(im,blank[0],blank[1],blank[6]||2,blank[3],blank[2],blank[4],blank[5],blank[3]);q.restore();}this._battleArt[key]=layer;}
 const k=Math.min(w/box[2],h/box[3]),dw=box[2]*k,dh=box[3]*k;this.ctx.save();this.ctx.imageSmoothingEnabled=true;this.ctx.imageSmoothingQuality='high';this.ctx.shadowColor='rgba(100,49,9,0.20)';this.ctx.shadowBlur=2;this.ctx.shadowOffsetY=1.3;this.ctx.drawImage(layer,x+(w-dw)/2,y+(h-dh)/2,dw,dh);this.ctx.restore();return true;};
 const previousBattleButton=p.button;
 p.button=function(label,x,y,w,h,action,primary){const boxes={'暂停':[32,99,147,81,28],'悔棋':[39,1381,195,106,34],'翻转':[243,1381,185,106,34],'重开':[438,1381,187,106,34],'更多':[635,1381,192,106,34],'表情':[661,1172,168,72,28]};
 const modalArt={'收起表情':['extra_buttons',[0,0,269,80]],'继续对局':['extra_buttons',[0,85,578,112]],'邀请微信好友':['waiting_reference',[122,644,621,112]],'取消等待':['waiting_reference',[123,783,620,112]],'再来一局':['result_reference',[120,827,625,112]],'查看棋局':['result_reference',[124,951,298,101]],'返回首页':['result_reference',[443,951,298,101]]}[label];
 if(this.runtime.scene==='game'&&modalArt&&this.battleArt(modalArt[1],x,y,w,h,modalArt[1][3]/2,null,modalArt[0])){this.targets.push({x,y,w,h,action});return;}
 const b=boxes[label];if(this.runtime.scene==='game'&&b&&this.battleArt(b.slice(0,4),x,y,w,h,b[4])){this.targets.push({x,y,w,h,action});return;}
 if(this.runtime.scene==='game'){const c=this.ctx,g=c.createLinearGradient(0,y,0,y+h);g.addColorStop(0,'#fffaa1');g.addColorStop(.42,'#ffe472');g.addColorStop(1,'#ffc249');c.save();c.shadowColor='#99551e66';c.shadowBlur=3;c.shadowOffsetY=2;this.rounded(x,y,w,h,18);c.fillStyle=g;c.fill();c.shadowBlur=0;c.shadowOffsetY=0;c.lineWidth=1.5;c.strokeStyle='#e8a134';c.stroke();this.rounded(x+2,y+2,w-4,h-5,16);c.strokeStyle='#fff4c6';c.stroke();c.restore();this.text(label,x+w/2,y+h/2,Math.min(17,w/(Array.from(label).length+2)),'#65300c','center',true);this.targets.push({x,y,w,h,action});return;}
 return previousBattleButton.call(this,label,x,y,w,h,action,primary);};
 const previousBattleCard=p.card;
 p.card=function(x,y,w,h,fill,stroke){if(this.runtime.scene!=='game')return previousBattleCard.call(this,x,y,w,h,fill,stroke);
 if(!fill){const g=this.ctx.createLinearGradient(0,y,0,y+h);g.addColorStop(0,'#fffbed');g.addColorStop(1,'#f8e6c5');fill=g;stroke='#e5ad48';}
 return previousBattleCard.call(this,x,y,w,h,fill,stroke);};
 // Cache the reference silhouette at its native resolution, keeping the bevel intact.
 p.battleTitleArt=function(x,y,w,h,originalLabel){const im=this.uiImage('game_reference');if(!im)return false;
 this._battleTitles=this._battleTitles||{};const key=originalLabel?'classic':'blank';let layer=this._battleTitles[key];
 if(!layer){layer=wx.createCanvas();layer.width=480;layer.height=120;const q=layer.getContext('2d');q.drawImage(im,190,64,480,120,0,0,480,120);
 const mask=wx.createCanvas();mask.width=480;mask.height=120;const mc=mask.getContext('2d');
 mc.beginPath();mc.moveTo(65,28);mc.lineTo(403,28);mc.bezierCurveTo(430,28,441,38,447,47);mc.bezierCurveTo(481,48,482,85,452,96);mc.bezierCurveTo(442,112,427,116,402,116);mc.lineTo(64,116);mc.bezierCurveTo(38,116,27,107,22,97);mc.bezierCurveTo(-1,93,-4,57,21,49);mc.bezierCurveTo(31,31,44,28,65,28);mc.closePath();mc.fill();
 mc.beginPath();mc.moveTo(23,28);mc.bezierCurveTo(2,20,2,18,5,14);mc.bezierCurveTo(19,12,32,20,34,30);mc.closePath();mc.moveTo(34,30);mc.bezierCurveTo(31,10,42,5,60,5);mc.bezierCurveTo(60,20,47,30,34,33);mc.closePath();mc.fill();
 q.globalCompositeOperation='destination-in';q.drawImage(mask,0,0);q.globalCompositeOperation='source-over';
 // Mirror the clean left end cap to the right, excluding foliage.
 const cap=wx.createCanvas();cap.width=80;cap.height=92;const cc=cap.getContext('2d');cc.beginPath();cc.moveTo(65,0);cc.lineTo(80,0);cc.lineTo(80,88);cc.lineTo(64,88);cc.bezierCurveTo(38,88,27,79,22,69);cc.bezierCurveTo(-1,65,-4,29,21,21);cc.bezierCurveTo(31,3,44,0,65,0);cc.closePath();cc.clip();cc.drawImage(layer,0,28,80,92,0,0,80,92);
 const cp=cc.getImageData(0,0,80,92);for(let i=0;i<cp.data.length;i+=4){if(cp.data[i+1]>cp.data[i]+4&&cp.data[i+1]>cp.data[i+2]+18)cp.data[i+3]=0;}cc.putImageData(cp,0,0);
 // Replace the foliage-covered upper bevel with the clean original upper-right bevel.
 // Keep the mirrored round end below it; use a smooth outline with no color-key holes.
 const bevel=wx.createCanvas();bevel.width=80;bevel.height=34;const bc=bevel.getContext('2d');
 bc.beginPath();bc.moveTo(0,0);bc.lineTo(5,0);bc.bezierCurveTo(25,0,35,7,45,18);bc.bezierCurveTo(60,18,71,26,76,34);bc.lineTo(0,34);bc.closePath();bc.clip();bc.drawImage(im,590,92,80,34,0,0,80,34);
 q.clearRect(400,0,80,120);q.save();q.translate(480,28);q.scale(-1,1);q.drawImage(cap,0,0);q.restore();q.clearRect(400,28,80,34);q.drawImage(bevel,400,28);

 if(!originalLabel){q.save();q.globalCompositeOperation='source-atop';for(let xx=92;xx<402;xx+=28){const ww=Math.min(28,402-xx);q.drawImage(im,252,111,ww,51,xx,47,ww,51);}q.restore();}
 this._battleTitles[key]=layer;}
 this.ctx.drawImage(layer,x-w*5/472,y-h*28/88,w*480/472,h*120/88);return true;};
 const previousBattleHeader=p.header;
 p.header=function(title,back=true){if(this.runtime.scene!=='game'||back)return previousBattleHeader.call(this,title,back);
 const x=83,y=this.top-17,w=220,h=40;
 if(!this.battleTitleArt(x,y,w,h,title==='经典象棋 · 对局中'))return previousBattleHeader.call(this,title,back);
 if(title==='经典象棋 · 对局中')return;
 this.ctx.save();this.ctx.shadowColor='#51250c';this.ctx.shadowBlur=1;this.ctx.shadowOffsetY=1;this.text(title,x+w/2,y+h/2,16,'#fff9ed','center',true);this.ctx.restore();};
 const previousBattlePlayer=p.player;
 p.player=function(side,name,avatar,y,captured,data,now,capturePlacement='below'){
 const red=side==='red',sy=red?1257:198,active=data.turn===side&&!data.ended&&!data.waiting;
 if(!this.battleArt([44,sy,774,105],16,y,343,48,42,[red?320:500,sy+12,114,81,12,red?651:610,250]))return previousBattlePlayer.call(this,side,name,avatar,y,captured,data,now,capturePlacement);
 // The source portrait is retained unless an actual player avatar is available.
 const c=this.ctx;c.save();c.beginPath();c.arc(45,y+24,18,0,Math.PI*2);c.clip();this.image(avatar,27,y+6,36,36);c.restore();
 const chars=Array.from((name||'').replace(/\s*·\s*/g,'·')),limit=active?5:13,short=chars.slice(0,limit).join('')+(chars.length>limit?'…':'');this.text(short,74,y+17,12.5,red?'#a52612':'#30302d','left',true);
 this.text(active?(data.paused?'计时暂停':'当前行棋'):'等待对方',74,y+34,11.5,'#a58c70','left',true);
 if(active){this.battleArt([590,1273,214,71],140.5,y+8,94,32,30,[665,1280,77,54,7,120]);this.ctx.save();this.ctx.shadowColor='#fff5ae';this.ctx.shadowOffsetY=0.6;this.text(data.seconds+'秒',226.5,y+25,19.5,'#c1200a','right',true);this.ctx.restore();}
 if(capturePlacement==='below')this.captureTray(captured,y+58);
 };
 p.preloadGameAssets=function(){if(this._v2Loading)return this._v2Loading;const a=require('./ui-assets'),keys=['extra_buttons','waiting_reference','result_reference','game_reference','board_base','capture_ring',...Object.keys(meta).filter(k=>((k.startsWith('v2_piece_')||k.startsWith('v2_fusion_'))&&!k.endsWith('_selected'))||k.startsWith('v2_player_bar_')||k.startsWith('v2_avatar_')||/^v2_button_00[5-9]$/.test(k)||k==='v2_button_010')];
 const pkgs=[...new Set(keys.map(k=>a[k].split('/')[0]))];this.uiPackages=this.uiPackages||{};
 this._v2Loading=Promise.all(pkgs.map(name=>new Promise(resolve=>{if(this.uiPackages[name]==='ready')return resolve(true);this.uiPackages[name]='loading';const done=ok=>{this.uiPackages[name]=ok?'ready':'failed';resolve(ok);};if(!wx.loadSubpackage)return done(true);try{wx.loadSubpackage({name,success:()=>done(true),fail:()=>done(false)});}catch(e){done(false);}}))).then(async results=>{const images=await Promise.all(keys.map(k=>{this.uiImage(k);const rec=this.images.get(a[k]);return rec&&(rec.image?true:rec.ready)||false;}));FX.preload(this);this.invalidate();return results.every(Boolean)&&images.every(Boolean);}).finally(()=>{this._v2Loading=null;});return this._v2Loading;
 };
}
module.exports={install};
