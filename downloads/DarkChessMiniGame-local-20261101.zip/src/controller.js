const FX=require('./battle-effects'),BattleTimeline=require('./battle-timeline');
const G=require('../utils/game-engine'),R=require('../utils/rules-core'),S=require('../utils/storage'),AI=require('../utils/ai'),Clock=require('../utils/turn-clock'),Audio=require('../utils/audio'),Online=require('../utils/online'),stickers=require('../utils/stickers');
const Repetition=require('../utils/repetition'),Fusion=require('../utils/fusion'),FakeOpponents=require('../utils/fake-opponents');
const names={red:'红方',black:'黑方'};
const MATCH_WAIT_SECONDS=15;
module.exports={
 data:{pieces:[],flipped:false,selectedId:'',turn:'red',topSide:'black',bottomSide:'red',topName:'黑方',bottomName:'红方',topCaptured:[],bottomCaptured:[],message:'',ply:0,showResult:false,resultTitle:'',resultDetail:'',unlucky:false,movingId:'',lastMoveId:'',revealId:'',captureId:'',ended:false,seconds:60,paused:false,mode:'ai',level:'normal',waiting:false,matchSeconds:0,topAvatar:'',bottomAvatar:'',stickers,showStickers:false,stickerImage:'',stickerText:'',roomId:'',busy:false,manualPaused:false},
 async onLoad(options){this._alive=true;this._token=0;this._audio=this.runtime&&this.runtime.audio||new Audio();this._audio.refresh();this._clock=new Clock();this._history=[];this._repetitionHistory=[];this._countdownCueKey='';this._fakeOpponent=null;this._matchQueue=options.mode==='online'&&options.match==='1';this._matchStartedAt=this._matchQueue?Date.now():0;this._state=G.newGame(undefined,options.variant||'dark');this._mode=options.mode==='online'?'online':'ai';this._level=['easy','normal','hard'].includes(options.level)?options.level:'normal';this.setData({mode:this._mode,level:this._level,matchSeconds:this._matchQueue?MATCH_WAIT_SECONDS:0});
  this._interval=setInterval(()=>this.tick(),250);
  if(this._mode==='online'){this.setData({waiting:true});try{await Promise.all(['stickersA','stickersB'].map(name=>new Promise((resolve,reject)=>wx.loadSubpackage({name,success:resolve,fail:reject}))));if(!this._alive)return;const action=options.room?'join':options.match==='1'?'match':'create';this.applyRoom(await Online.call(action,{roomId:options.room,variant:options.variant||'dark'}));if(this._alive)this._poll=setInterval(()=>this.poll(),1200);}catch(e){this.toast(e.message);this.home();}}
  else {this.loadStickers();this._clock.start();this.sync();}
 },
 onShow(){this._hidden=false;if(this._alive&&!this._interval)this._interval=setInterval(()=>this.tick(),250);if(this._alive&&this._room&&!this._poll)this._poll=setInterval(()=>this.poll(),1200);if(this._audio)this._audio.refresh();if(this._clock){this.tick();this.scheduleAI();}if(this._room)this.poll();},
 onHide(){this.clearPresentation();this._warningPhase=null;this._hidden=true;this._token++;clearInterval(this._interval);clearInterval(this._poll);this._interval=null;this._poll=null;if(this._audio)this._audio.hide();/* Clock intentionally continues in background. */},
 onUnload(){this.clearPresentation();this._warningPhase=null;clearTimeout(this._resultTimer);clearTimeout(this._moveAudioTimer);if(this._aiDelayResolve){clearTimeout(this._aiDelayTimer);this._aiDelayResolve();this._aiDelayResolve=null;}clearTimeout(this._fakeStickerTimer);this._alive=false;this._token++;clearInterval(this._interval);clearInterval(this._poll);clearTimeout(this._checkTimer);clearTimeout(this._stickerTimer);if(this._audio){if(this.runtime&&this.runtime.audio===this._audio)this._audio.hide();else this._audio.destroy();}},
 toast(title){wx.showToast({title,icon:'none'});},
 tick(){if(!this._alive||!this._state||this._state.status!=='playing')return;
  if(this._mode==='online'){if(this._room&&this._room.waiting){if(this._matchQueue){const left=Math.max(0,MATCH_WAIT_SECONDS-Math.floor((Date.now()-this._matchStartedAt)/1000));this.setData({matchSeconds:left});if(left<=0){this.activateFakeOpponent();}}return;}if(!this._room)return;const now=Date.now()+this._offset,r=this._room;const pause=Math.max(0,r.pending?r.pending.until-now:r.holdUntil-now);const seconds=Math.max(0,Math.min(60,Math.ceil((r.deadline-now-pause)/1000)));this.setData({seconds,paused:pause>0});this.countdownCue(seconds);return;}
  const seconds=this._clock.seconds(),paused=this._clock.reasons.size>0;if(seconds!==this.data.seconds||paused!==this.data.paused)this.setData({seconds,paused});this.countdownCue(seconds);if(this._clock.expired()){this._token++;this._state={...this._state,status:'ended',reason:'timeout',motif:'超时判负',winner:R.opposite(this._state.turn)};this.sync('timeout');}
 },
 countdownCue(seconds){if(seconds>10||!this._audio||!this._state||this._state.status!=='playing')return;const key=this._state.ply+':'+this._state.turn;if(this._countdownCueKey===key)return;this._countdownCueKey=key;this._audio.speak('47_十秒倒计时_渐进版.wav');},
 async activateFakeOpponent(){
  if(!this._alive||this._mode!=='online'||!this._matchQueue||!this._room||!this._room.waiting||this._fakeOpponent||this._botActivating)return;
  this._botActivating=true;const pending=this._room;
  try{
   // Recheck the authoritative room before falling back, avoiding a race with a
   // real opponent who joined during the last polling interval.
   try{const latest=await Online.call('poll',{roomId:pending.roomId,rev:pending.rev});if(!this._alive||this._room!==pending)return;if(!latest.waiting){this.applyRoom(latest);return;}}catch(e){}
   if(!this._alive||this._mode!=='online'||this._room!==pending||!pending.waiting)return;
   const bot=FakeOpponents.pick();this._fakeOpponent=bot;this._token++;clearInterval(this._poll);this._poll=null;this._room=null;this._mode='ai';this._level='hard';this._clock.start();
   Online.call('cancel').catch(()=>{});
   this.setData({mode:'ai',level:'hard',waiting:false,matchSeconds:0,roomId:'',message:bot.nickname+' 已入座'});this.sync();this.scheduleAI();
  }finally{this._botActivating=false;}
 },
 sync(event){if(this._state.status==='ended'&&['timeout','resign','draw','mutual-check','perpetual-check'].includes(this._state.reason))event=this._state.reason==='timeout'?'timeout':'end';const moved=['fusion','chase','move','capture','reveal','check','checkmate','stalemate','unlucky'].includes(event);const s=this._state;if(s.status==='ended'&&!moved)this.motion=null;if(this._repetitionHistory&&this._repetitionHistory.some(v=>v.ply>=s.ply)){this._repetitionHistory=this._repetitionHistory.filter(v=>v.ply<s.ply);this._longCheckWarning=null;}const top=this.data.flipped?'red':'black',bottom=R.opposite(top),ended=s.status==='ended',last=s.lastMove;const rp=this._room;
  const player=side=>rp&&rp[side]?rp[side].nickname:this._fakeOpponent&&side==='black'?this._fakeOpponent.nickname:this._mode==='ai'&&side==='black'?({easy:'简易 · 菜就多练局',normal:'普通 · 不服就干场',hard:'困难 · 棋王修罗场'}[this._level]):names[side]+' · 你';
  const patch={pieces:G.displayPieces(s.pieces),turn:s.turn,topSide:top,bottomSide:bottom,topName:player(top),bottomName:player(bottom),topAvatar:rp&&rp[top]?rp[top].avatar:'',bottomAvatar:rp&&rp[bottom]?rp[bottom].avatar:'',topCaptured:s.captured.filter(p=>p.capturedBy===top),bottomCaptured:s.captured.filter(p=>p.capturedBy===bottom),message:ended?'对局结束':rp&&rp.waiting?'等待真人对手':G.checked(s.pieces,s.turn)?names[s.turn]+'被将军，必须应将':names[s.turn]+'行棋',ply:s.ply,selectedId:s.pendingChase||'',pendingChase:s.pendingChase||null,fusionUsed:s.fusionUsed||null,ended,showResult:ended?this.data.showResult:false,resultTitle:ended?s.motif:'',resultDetail:ended?(s.winner?names[s.winner]+'获胜':'双方和棋'):'',unlucky:ended&&s.reason==='unlucky',movingId:moved&&last?last.id:'',lastMoveId:last?last.id:'',revealId:moved&&last&&last.revealed?last.id:'',captureId:moved&&last&&last.capturedId?last.id:''};if(this._mode!=='online'&&this._clock){patch.seconds=this._clock.seconds();patch.paused=this._clock.reasons.size>0;}this.presentTransition(event,s,patch);this.setData(patch);this.updateResult(ended,s);
 },
 clearPresentation(){if(this._audio&&this._audio.cancelBattleQueue)this._audio.cancelBattleQueue();if(this._battle)this._battle.clear();this.motion=null;this.cue=null;clearTimeout(this._moveAudioTimer);for(const sound of this._battleSounds||[])clearTimeout(sound.timer);this._battleSounds=[];},
 pausePresentation(){if(this._battle)this._battle.pause();this._visualPauseAt=Date.now();for(const sound of this._battleSounds||[])clearTimeout(sound.timer);},
 resumePresentation(){const now=Date.now(),delta=this._visualPauseAt===undefined?0:now-this._visualPauseAt;if(this._battle)this._battle.resume(now);for(const sound of this._battleSounds||[]){sound.at+=delta;this.armBattleSound(sound);}this._visualPauseAt=undefined;},
 armBattleSound(sound){sound.timer=setTimeout(()=>{const list=this._battleSounds||[],i=list.indexOf(sound);if(i<0)return;list.splice(i,1);if(this._alive&&!this._hidden&&!this.data.manualPaused)this._audio.event(sound.event,sound.state);},Math.max(0,sound.at-Date.now()));},
 presentTransition(event,state,patch){
  const now=Date.now(),last=state.lastMove,moved=['fusion','chase','move','capture','reveal','check','checkmate','stalemate','unlucky'].includes(event);
  const key=last?JSON.stringify([state.variant,state.ply,last,state.captured.length]):'';
  const terminalKey=state.status==='ended'?JSON.stringify([state.ply,state.reason,state.winner,last]):null;
  if(terminalKey&&terminalKey===this._presentedTerminalKey&&!moved){this._presentedState=state;return;}
  this._presentedTerminalKey=terminalKey;
  if(!this._battle)this._battle=new BattleTimeline();
  if(this._hidden){this.clearPresentation();this._presentedState=state;this._presentedMoveKey=key;return;}
  if(moved&&last&&key!==this._presentedMoveKey){
   const pieces=patch.pieces;let before=this.data.pieces||[],beforeBySide={[this.data.topSide||'black']:this.data.topCaptured||[],[this.data.bottomSide||'red']:this.data.bottomCaptured||[]};
   // A poll can contain both chase hops. Replay only the authoritative firstHop we have not seen.
   const first=last.firstHop;
   if(first&&state.variant==='fusion'&&first.id===last.id&&JSON.stringify(this._presentedState&&this._presentedState.lastMove)!==JSON.stringify(first)){
    const firstIds=new Set(first.capturedIds||[first.capturedId]),secondIds=new Set(last.capturedIds||[last.capturedId]),secondSources=new Set();
    for(const p of before)if(secondIds.has(p.id))for(const source of p.sourcePieces||[p])secondSources.add(source.id);
    const intermediate=before.filter(p=>!firstIds.has(p.id)).map(p=>p.id===first.id?{...p,...first.to}:p),firstCaptured=state.captured.filter(p=>!secondSources.has(p.id));
    const midBySide={red:firstCaptured.filter(p=>p.capturedBy==='red'),black:firstCaptured.filter(p=>p.capturedBy==='black')};
    const firstState={...state,status:'playing',reason:null,winner:null,motif:null,turn:first.actor,ply:Math.max(0,state.ply-1),pieces:intermediate,captured:firstCaptured,lastMove:first,pendingChase:first.id};
    const e=this._battle.enqueue(first,{pieces:intermediate,removedPieces:before.filter(p=>firstIds.has(p.id)),lastMoveId:first.id,beforeLastMoveId:this.data.lastMoveId,beforeBySide,afterBySide:midBySide},'chase',firstState,now);
    const sound={event:'chase',state:firstState,at:e.at+e.timings.impact};(this._battleSounds||(this._battleSounds=[])).push(sound);this.armBattleSound(sound);
    before=intermediate;beforeBySide=midBySide;
   }
   const removed=[];for(const p of before)if(p.id!==last.id&&!pieces.some(q=>q.id===p.id))removed.push(p);
   const view={pieces,removedPieces:removed,lastMoveId:last.id,beforeLastMoveId:first?first.id:this.data.lastMoveId,beforeBySide,afterBySide:{[patch.topSide]:patch.topCaptured,[patch.bottomSide]:patch.bottomCaptured}};
   const e=this._battle.enqueue(last,view,event,state,now);this.motion=this._battle.advance(now);
   const sound={event,state,at:e.at+e.timings.impact};(this._battleSounds||(this._battleSounds=[])).push(sound);this.armBattleSound(sound);
  }else if(!moved&&(event||this._presentedState!==state)){
   this.clearPresentation();
   if(event&&state.status==='ended')this._battle.cues.push({at:now,duration:650,reason:state.reason,warning:false});
   if(event)this._audio.event(event,state);
  }
  this._presentedState=state;this._presentedMoveKey=key;
 },
 updateResult(ended,state){if(!ended){clearTimeout(this._resultTimer);this._resultKey=null;return;}const key=JSON.stringify([state.ply,state.reason,state.winner,state.motif]);if(this._resultKey===key)return;this._resultKey=key;clearTimeout(this._resultTimer);this.setData({showResult:false});this._resultTimer=setTimeout(()=>{const current=this._state;if(this._alive&&current.status==='ended'&&JSON.stringify([current.ply,current.reason,current.winner,current.motif])===key)this.setData({showResult:true});},Math.max(2000,this.motion?FX.timing(this.motion.move).total+450:2000));},

 endLongCheck(side){this._token++;this._state={...this._state,status:'ended',winner:R.opposite(side),reason:'perpetual-check',motif:'长将判负'};this.sync('end');},
 repetitionForMove(move){const piece=this._state.pieces.find(p=>p.id===move.id);if(!piece||piece.hidden)return null;const actor=this._state.turn,publicPieces=AI.publicBoard(this._state.pieces),candidate={...this._state,pieces:AI.apply(publicPieces,move,actor),turn:R.opposite(actor)};return Repetition.analyze([...(this._repetitionHistory||this._history),this._state],candidate);},

 localMove(id,to){this.tick();if(this._state.status!=='playing'||this._clock.reasons.size)return false;const result=G.move(this._state,id,to);if(!result.ok){this.toast(result.message);return false;}const repeat=this._state.variant==='fusion'?null:Repetition.analyze([...(this._repetitionHistory||this._history),this._state],result.state);if(repeat&&repeat.kind==='perpetual'&&repeat.offender===this._state.turn){if(this._longCheckWarning&&this._longCheckWarning.ply===this._state.ply&&this._longCheckWarning.side===this._state.turn){this.endLongCheck(this._state.turn);return false;}this._longCheckWarning={ply:this._state.ply,side:this._state.turn};this.setData({message:'单方长将：必须变招，再次循环将军直接判负',selectedId:''});this.toast('单方长将，请变招；再次重复将判负');return false;}this._longCheckWarning=null;if(repeat&&repeat.kind==='mutual'){result.state={...result.state,status:'ended',winner:null,reason:'mutual-check',motif:'循环互将和棋'};result.event='end';}if(!this._repetitionHistory)this._repetitionHistory=this._history.slice();if(result.state.lastMove.revealed||result.state.lastMove.capturedId)this._repetitionHistory=[];else this._repetitionHistory.push(this._state);if(!this._state.pendingChase)this._history.push(this._state);this._history=this._history.slice(-100);const sameTurn=result.state.turn===this._state.turn;this._state=result.state;if(!sameTurn)this._clock.start();if(result.event==='check'){this._clock.pause('check');clearTimeout(this._checkTimer);this._checkTimer=setTimeout(()=>{this._clock.resume('check');this.scheduleAI();},1200);}this.sync(result.event);if(repeat&&repeat.kind==='perpetual'&&repeat.offender===this._state.turn&&this._state.status==='playing'){this._longCheckWarning={side:repeat.offender,ply:this._state.ply};this.setData({message:names[repeat.offender]+'单方长将：必须变招，否则判负'});this.toast(names[repeat.offender]+'单方长将，请变招');}this.scheduleAI();return true;},
 async scheduleAI(){if(!this._alive||this._mode!=='ai'||this._hidden||this._aiThinking||!this._state||this._state.status!=='playing'||this._state.turn!=='black'||this._clock.reasons.size)return;
  this._aiThinking=true;const token=this._token,started=Date.now(),snapshot=this._state;try{
   // Let the previous move finish before starting CPU-heavy search.
   const settle=this.motion?Math.max(0,FX.timing(this.motion.move).total-(Date.now()-this.motion.at)):0;
   if(settle)await new Promise(resolve=>{this._aiDelayResolve=resolve;this._aiDelayTimer=setTimeout(()=>{this._aiDelayResolve=null;resolve();},settle);});
   if(!this._alive||this._hidden||this._clock.reasons.size||token!==this._token||this._state!==snapshot)return;
   const m=snapshot.variant==='fusion'?await require('../utils/fusion-ai').choose(snapshot,this._level,{cancel:()=>!this._alive||this._hidden||this._clock.reasons.size>0||token!==this._token||this._state!==snapshot}):await AI.choose(snapshot.pieces,'black',this._level,{history:[...(this._repetitionHistory||this._history||[]),snapshot],cancel:()=>!this._alive||this._hidden||this._clock.reasons.size>0||token!==this._token||this._state!==snapshot,allowMove:move=>{const repeat=this.repetitionForMove(move);return !repeat||repeat.kind!=='perpetual'||repeat.offender!=='black';}});
   const thinkFloor=this._fakeOpponent?900+Math.floor(Math.random()*3300):2000;const wait=Math.max(0,thinkFloor-(Date.now()-started));if(wait&&this._alive&&token===this._token)await new Promise(resolve=>{this._aiDelayResolve=resolve;this._aiDelayTimer=setTimeout(()=>{this._aiDelayResolve=null;resolve();},wait);});
   if(token===this._token&&this._alive&&!this._hidden&&this._state===snapshot&&!this._clock.reasons.size){if(m){this.localMove(m.id,m.to);if(this._fakeOpponent&&Math.random()<.22){const id=stickers[Math.floor(Math.random()*stickers.length)].id;clearTimeout(this._fakeStickerTimer);this._fakeStickerTimer=setTimeout(()=>{if(this._alive&&this._fakeOpponent&&this._state.status==='playing')this.showSticker(id);},250+Math.floor(Math.random()*900));}}else if(snapshot.variant!=='fusion'){const moves=AI.moves(AI.publicBoard(snapshot.pieces),'black');if(moves.length&&moves.every(move=>{const repeat=this.repetitionForMove(move);return repeat&&repeat.kind==='perpetual'&&repeat.offender==='black';}))this.endLongCheck('black');}}
  }finally{this._aiThinking=false;if(this._alive)setTimeout(()=>this.scheduleAI(),50);}
 },
 togglePause(){if(this._mode!=='ai'||this._state.status!=='playing')return;this.tick();if(this._state.status!=='playing')return;
  const paused=!this.data.manualPaused;this._token++;if(paused){this._clock.pause('manual');this.pausePresentation();}else{this._clock.resume('manual');this.resumePresentation();}this.setData({manualPaused:paused,paused:this._clock.reasons.size>0,selectedId:''});if(!paused)this.scheduleAI();
 },
 loadStickers(){if(this._stickersReady)return Promise.resolve(true);if(this._stickersLoading)return this._stickersLoading;
  this._stickersLoading=Promise.all(['stickersA','stickersB'].map(name=>new Promise((resolve,reject)=>{if(!wx.loadSubpackage)return resolve();wx.loadSubpackage({name,success:resolve,fail:reject});}))).then(()=>{this._stickersReady=true;return true;}).catch(()=>false).finally(()=>{this._stickersLoading=null;});return this._stickersLoading;
 },

 async onPoint(e){this.tick();if(this._state.status!=='playing'||this.data.waiting||this.data.busy||this.data.paused)return;if(this._mode==='ai'&&this._state.turn!=='red')return;if(this._mode==='online'&&this._state.turn!==this._room.side)return;
  const {point,pieceId}=e.detail,p=this._state.pieces.find(v=>v.id===pieceId),selected=this.data.selectedId;if(selected===pieceId){if(this._battle)this._battle.select(null);this.setData({selectedId:''});return;}
  if(this._state.variant==='fusion'&&selected&&Fusion.attempt(this._state,selected,point)){
   const a=Fusion.attempt(this._state,selected,point);const execute=()=>this._mode==='online'?this.command('move',{id:selected,to:point}):this.localMove(selected,point);
   if(a.fusion){const snapshot=this._state;this.modal('确认合棋',a.p.text+' + '+p.text+' → '+Fusion.names[a.fusion],()=>{if(this._state!==snapshot)return;this._clock.resume('modal');execute();});}else await execute();return;
  }
  if(this._state.variant!=='fusion'&&selected&&G.legalAttempt(this._state.pieces,selected,point,this._state.turn)){if(this._mode==='online')await this.command('move',{id:selected,to:point});else this.localMove(selected,point);return;}
  if(p&&R.controller(p)===this._state.turn&&(!this._state.pendingChase||p.id===this._state.pendingChase)){if(!this._battle)this._battle=new BattleTimeline();this._battle.select(p.id);this.setData({selectedId:p.id});this._audio.effect('pickup');}else this._audio.effect('forbidden');
 },
 finishChase(){if(!this._state.pendingChase||this.data.paused||this._mode==='ai'&&this._state.turn!=='red'||this._mode==='online'&&this._state.turn!==this._room.side)return;const id=this._state.pendingChase;return this._mode==='online'?this.command('move',{id,to:null}):this.localMove(id,null);},
 flip(){this.setData({flipped:!this.data.flipped});this.sync();},
 modal(title,content,fn){this.tick();if(this._state.status==='playing')this._clock.pause('modal');this._token++;wx.showModal({title,content,success:r=>{this._audio.effect('click');if(r.confirm)fn();},complete:()=>{this._clock.resume('modal');this.tick();this.scheduleAI();}});},
 restart(){if(this._mode==='online'){this.command('request',{kind:'restart'});return;}this.modal('重新开始','重新洗牌并开始新对局？',()=>{this._state=G.newGame(undefined,this._state.variant||'dark');this._history=[];this._repetitionHistory=[];this._longCheckWarning=null;this._clock.start();this.sync();});},
 undo(){if(this._state.status!=='playing')return this.toast('对局已结束，请重开');if(this._mode==='online'){this.command('request',{kind:'undo'});return;}if(!this._history.length)return this.toast('没有可悔棋记录');this.modal('确认悔棋','退回你上一次行棋之前。已看到的暗子身份不会从记忆中消失。',()=>{do{this._state=this._history.pop();}while(this._state.turn!=='red'&&this._history.length);this._clock.start();this.sync();});},
 async more(){if(this._menuOpen)return;this._menuOpen=true;this.tick();this._token++;let choice;
  if(this._mode==='ai'&&this._state.status==='playing'){this._clock.pause('more');this.tick();}
  else if(this._mode==='online'&&this._state.status==='playing'){await this.command('menuOpen');if(this._room&&this._room.menuPause)this.toast('真人局菜单最多暂停15秒');}
  if(!this._alive){this._menuOpen=false;return;}
  try{wx.showActionSheet({itemList:['认输','协商和棋','游戏规则','声音设置','返回首页'],success:r=>{choice=r.tapIndex;this._audio.effect('click');},complete:()=>this.closeMore(choice)});}catch(error){this.closeMore();}
 },
 async closeMore(choice){if(this._mode==='ai'){this._clock.resume('more');this.tick();}else if(this._room&&this._room.menuPause&&this._room.menuPause.by===this._room.side)await this.command('menuClose');this._menuOpen=false;if(!this._alive)return;this.moreAction(choice);this.scheduleAI();},
 moreAction(choice){if(choice===0){if(this._mode==='online')this.command('resign');else this.modal('确认认输','确认后本局结束。',()=>{this._state={...this._state,status:'ended',winner:'black',reason:'resign',motif:'认输'};this.sync('end');});}else if(choice===1){if(this._mode==='online')this.command('request',{kind:'draw'});else this.toast('人机练习不接受协商和棋');}else if(choice===2)this.runtime.open('rules');else if(choice===3)this.runtime.open('settings');else if(choice===4)this.home();},

 async command(action,data={}){if(this.data.busy||!this._room)return;this.setData({busy:true});try{this.applyRoom(await Online.call(action,{...data,roomId:this._room.roomId,rev:this._room.rev}));}catch(e){this.toast(e.message);await this.poll();}finally{if(this._alive)this.setData({busy:false,manualPaused:false});}},
 async poll(){if(!this._room||this._polling||!this._alive||this._hidden)return;this._polling=true;try{this.applyRoom(await Online.call('poll',{roomId:this._room.roomId}));this._networkWarned=false;}catch(e){if(!this._networkWarned){this._networkWarned=true;this.toast('连接中断，重连中；服务器仍在计时');}}finally{this._polling=false;}},
 applyRoom(room){if(!this._alive||this._room&&room.rev<this._room.rev)return;const old=this._room;this._offset=room.serverNow-Date.now();this._room=room;this._state=room.state;if(this.runtime)this.runtime.variant=room.state.variant||'dark';this.setData({waiting:room.waiting,roomId:room.roomId});const changed=!old||JSON.stringify(old.state)!==JSON.stringify(room.state)||old.waiting!==room.waiting; if(changed){this.sync(old?room.event:undefined);}
  this.tick();if(room.sticker&&(!old||!old.sticker||old.sticker.seq!==room.sticker.seq)&&room.serverNow-room.sticker.at<4000)this.showSticker(room.sticker.id);
  const p=room.pending;if(p&&p.by!==room.side&&this._promptKey!==p.until){this._promptKey=p.until;wx.showModal({title:'对方请求'+({undo:'悔棋',restart:'重开',draw:'和棋'}[p.kind]),content:'计时暂停，15 秒内确认。悔棋会保留双方对已翻暗子的记忆。',success:r=>this.command('reply',{accept:r.confirm})});}
 },
 onShareAppMessage(){return {title:'暗棋大乱斗 · 来一局中国象棋',query:'room='+encodeURIComponent(this.data.roomId)};},
 async toggleStickers(){if(this.data.showStickers){this.setData({showStickers:false});return;}const ready=await this.loadStickers();if(!this._alive)return;if(!ready)return this.toast('表情加载失败，请重试');this.setData({showStickers:true});},
 sendSticker(e){this.setData({showStickers:false});const id=e.currentTarget.dataset.id;if(this._mode==='ai')this.showSticker(id);else this.command('sticker',{id});},
 showSticker(id){const s=stickers.find(v=>v.id===id);if(!s)return;clearTimeout(this._stickerTimer);this.setData({stickerImage:s.image,stickerText:s.text});if(!this._hidden)this._audio.speak(s.voice||s.text);this._stickerTimer=setTimeout(()=>{if(this._alive)this.setData({stickerImage:'',stickerText:''});},3000);},
 async cancelWait(){if(this._room){try{await Online.call('cancel');}catch(e){this.toast(e.message);return;}}this.home();},
 closeResult(){this.setData({showResult:false});},home(){this.runtime.home();}
};
